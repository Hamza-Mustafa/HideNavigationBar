# HideNavigationBar
How to hide navigation bar with Swift
